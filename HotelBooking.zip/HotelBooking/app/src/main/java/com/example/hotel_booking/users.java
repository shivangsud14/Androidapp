package com.example.hotel_booking;

public class users {
    public String FullName,Email,Phone;

    public users(){

    }

    public users(String fullName, String email, String phone) {
        FullName = fullName;
        Email = email;
        Phone = phone;
    }
}
